 

<?php $__env->startSection('title'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
<div class="col-xs-12">
    <div class="card">
        <div class="header">
            <h2 class="text-center mt-3">DATA MOBIL</h2><hr>
        </div>
        <div class="card-body">
             <a class="btn btn-primary mb-3" href="/mobil_create"><i class="fas fa-plus"></i> Tambah Data</a>
        </div>
    <div class="body">
            <?php if(Session::get('alert_pesan')): ?>
                <div class="alert alert-success">
                <strong><?php echo e(Session::get('alert_pesan')); ?></strong>
                </div>
            <?php endif; ?>
            <table class="table table-hover table-striped">
                    <tr class="table bg-dark text-light" >
                        <td>NO</td>
                        <td>NAMA MOBIL</td>
                        <td>MERK</td>
                        <td>WARNA</td>
                        <td>TAHUN</td>
                        <td>BIAYA PERHARI</td>
                        <td>IMAGE</td>
                     
                        <td>Aksi</td>
                    </tr>
                        <?php $no=0; ?>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++; ?>
                    <tr>
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e($data->nomor_mobil); ?></td>
                        <td><?php echo e($data->nama_mobil); ?></td>
                        <td><?php echo e($data->merk); ?></td>
                        <td><?php echo e($data->warna); ?></td>
                        <td><?php echo e($data->tahun_pembuatan); ?></td>
                        <td><?php echo e($data->biaya_perhari); ?></td>
                        <td><img width="40" src="<?php echo e(asset('gambar/'.$data->foto)); ?>"></td>
                        <td>
                            <a href="/mobil/detail/<?php echo e($data->id_mobil); ?>"  class="btn btn-info">Detail</a>
                            <a href="/mobil/edit/<?php echo e($data->id_mobil); ?>"  class="btn btn-warning">Edit</a>
                            <a href="/mobil/hapus/<?php echo e($data->id_mobil); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rental\resources\views/mobil.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('container'); ?>
 
    <section class="ftco-section services-section img" style="background-image: url(images/bg_2.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
          <br><br>
          	
            <h2 class="mb-3">RENTAL MOBIL</h2>
            <span class="subheading">   by <i class="icon-heart color-danger" aria-hidden="true"></i> <a href="/" target="_blank">ALPHAMIDI</a>
          </div>
        </div>
    	</div>
    </div>
    </section>
    <section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
          	<span class="subheading">KELOMPOK 10</span>
            <h2 class="mb-3">LARAVEL PROJECT</h2>
          </div>
        </div>
        <div class="row ftco-animate">  
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/bagas.jpg)">
                  </div>
                  <div class="text pt-4">
                    <p class="mb-4">"Syukuri setiap hal yang kau miliki, karena bisa jadi hal yang kau miliki tidak dimiliki oleh orang lain dan mereka sangat menginginkan hal tersebut."</p>
                    <p class="name">MUHAMMAD BAGAS RAMADHAN</p>
                    <span class="position" style="color:black">XI RPL 7 - 24</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/derik.jpg)">
                  </div>
                  <div class="text pt-4">
                    <p class="mb-4">"Kesuksesan dan kegagalan merupakan bagian yang akan selalu ada dalam hidup ini. Keduanya bukanlah hal yang permanen, sehingga akan selalu datang silih berganti."</p>
                    <p class="name">FREDERICK MAULANA THORIQ ELHAQ</p>
                    <span class="position" style="color:black">XI RPL 7 - 16</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/vito.jpg)">
                  </div>
                  <div class="text pt-4">
                    <p class="mb-4">"Semua emosi atau perasaan selalu berawal dari pikiran. Bahkan yang memutuskan untuk dapat menjadi orang paling bahagia saat ini dan seterusnya adalah Anda sendiri dana pa yang ada dalam pikiran Anda."</p>
                    <p class="name">AKBAR VITO HARTONO</p>
                    <span class="position" style="color:black">XI RPL 7 - 4</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/isqi.jpg)">
                  </div>
                  <div class="text pt-4">
                    <p class="mb-4">"Mulailah untuk melangkah, karena memulai melangkah itu bukan hal yang mudah. Langkah pertama tersebut sama artinya dengan sudah melangkah sampai setengah perjalanan dari target Anda."</p>
                    <p class="name">ISYIQI FIRDAUS</p>
                    <span class="position" style="color:black" >XI RPL 7 - 19</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/damar.jpg)">
                  </div>
                  <div class="text pt-4">
                    <p class="mb-4">"Kesuksesan itu seperti menjalankan roda. Terasa berat pada awal mendorong roda, hanya saja menjadi ringan setelah roda tersebut berjalan."</p>
                    <p class="name">DAMAR RAIHAN CHOIRUL FIRDAUS</p>
                    <span class="position" style="color:black" >XI RPL 7 - 11</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<hr>
		

    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rental\resources\views/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title',  'Edit'); ?> 

<?php $__env->startSection('container'); ?>
 
<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('../../images/bg_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
        </div>
      </div>
    </section>
<div class="container">
  <section class="main-section">
    <div class="content">
    <hr>
      <h1 style="text-align:center">Edit Data Mobil</h1>
      <hr>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><strong><?php echo e($error); ?></strong></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/mobil/update" method="post">
        <input type="hidden" name="id" value="<?php echo e($datas->id_mobil); ?>"> <br/>
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="nama">Nama Mobil</label>
            <input type="text" class="form-control"  name="nama_mobil" value="<?php echo e($datas->nama_mobil); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="nomor_mobil">Nomor Mobil</label>
            <input type="text" class="form-control"  name="nomor_mobil" value="<?php echo e($datas->nomor_mobil); ?>"required="required">
          </div>
          <div class="form-group">
            <label for="merk">Merk</label>
            <input type="text" class="form-control"  name="merk" value="<?php echo e($datas->merk); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="warna">Warna</label>
            <input type="text" class="form-control"  name="warna" value="<?php echo e($datas->warna); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="tahun_pembuatan">Tahun Pembuatan</label>
            <input type="date"  class="form-control" name="tahun_pembuatan" value="<?php echo e($datas->tahun_pembuatan); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="biaya_perhari">Biaya Perhari</label>
            <input type="text" class="form-control" name="biaya_perhari"  value="<?php echo e($datas->biaya_perhari); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="images">Gambar</label>
            <input type="file"  class="form-control" name="images"  value="<?php echo e($datas->images); ?>" required="required">
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <input type="text"  class="form-control" name="deskripsi" value="<?php echo e($datas->deskripsi); ?>" required="required">
            
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-md btn-primary">Submit</button>
            <button type="reset" class="btn btn-md btn-danger">Cancel</button>
          </div>
        
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </section>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rental\resources\views/mobil_edit.blade.php ENDPATH**/ ?>
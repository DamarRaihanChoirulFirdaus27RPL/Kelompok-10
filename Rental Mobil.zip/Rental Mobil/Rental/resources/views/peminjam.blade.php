@extends('layout.main')
@section('title', 'Data') 
@section('container')
<script type="text/javascript">
	function Print() {
		var printDoc = document.getElementById('report').innerHTML;
		// yang dicetak
		var originalDoc = document.body.innerHTML;
		document.body.innerHTML = printDoc;
		window.print();
		document.body.innerHTML = originalDoc;
	}
    </script>

<section class="ftco-section services-section img" style="background-image: url(images/bg_2.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
            <h2 class="mb-3">DATA MOBIL</h2>
            <span class="subheading">   by <i class="icon-heart color-danger" aria-hidden="true"></i> <a href="/" target="_blank">ALPHAMIDI</a>
          </div>
        </div>
    	</div>
    </div>
    </section>
    <div class="main" >
    <div class="main-content">
        <div class="container-flud">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel">
                        <div class="heading">
                            <div class="panel-title" id="report">
                                    <div class="container"></div>
<div class="col-xs-12">
    <div class="card">
        <div class="header">
            <h2 class="text-center">DATA PEMINJAM</h2><hr>
        </div>
    <div class="request-form">
            @if(Session::get('alert_pesan'))
                <div class="alert alert-success">
                <strong>{{Session::get('alert_pesan')}}</strong>
                </div>
            @endif
            
            <table class="table table-hover table-striped">
                    <tr>
                        <td>NO</td>
                        <td>NAMA</td>
                        <td>NAMA MOBIL</td>
                        <td>TANGGAL PEMINJAMAN</td>
                        <td>TANGGAL KEMBALI</td>
                        <td>AKSI<td>
                    </tr>
                        @php $no=0; @endphp
                        @foreach($datas as $data)
                        @php $no++; @endphp
                    <tr>
                        <td>{{$no}}</td>
                        <td>{{$data->nama_pelanggan}}</td>
                        <td>{{$data->nama_mobil}}</td>
                        <td>{{$data->tgl_pinjam}}</td>
                        <td>{{$data->tgl_kembali}}</td>
                        <td><a href="/sewa/hapus/{{ $data->id_sewa }}" class="btn btn-black btn-outline-black ml-1">Kembalikan</a></td>
                    </tr>
                    @endforeach
            </table>
            <button type="button" class="btn btn-success" onclick="Print()">
    <i class="lnr lnr-printer"> print</i>
    </button>
            <hr>
            
        </div>
        
    </div>
    </div>
@stop
     
@extends('layout.main')

@section('title','Sewa')

@section('container')
    
<section class="ftco-section services-section img" style="background-image: url(images/bg_2.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
          <br><br>
          	
            <h2 class="mb-3">SEWA MOBIL</h2>
            <span class="subheading">   by <i class="icon-heart color-danger" aria-hidden="true"></i> <a href="/" target="_blank">ALPHAMIDI</a>
          </div>
        </div>
    	</div>
    </div>
    </section>
	
    <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="car-list">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>&nbsp;</th>
						        <th>&nbsp;</th>
						        <th class="bg-primary heading">Per Jam</th>
						        <th class="bg-dark heading">Harian</th>
						        <th class="bg-black heading">Bulanan</th>
						      </tr>
						    </thead>
						    <tbody>
							@foreach($datas as $data)
						      <tr class="">
								  <td class="car-image"><div><img width="180px" height="100px"  src="{{asset('images/'.$data->images)}}"></div></td>
						        <td class="product-name">
						        	<h3><a>{{$data -> nama_mobil}}</a></h3>
						        	<p class="mb-0 rated">
						        		<span class="center" style="color:black">{{$data -> merk}}</span>
						        	</p>
						        </td>
						        
						        <td class="price">
						        	<p class="btn-custom"><a href="#">Detail</a></p>
						        	<div class="price-rate">
							        	<h3>
							        		<span class="num">Rp -</span>
							        		<span class="per">/per jam</span>
							        	</h3>
							        	<span class="subheading">-</span>
						        	</div>
						        </td>
						        
						        <td class="price">
						        	<p class="btn-custom"><a href="/mobil/detail/{{ $data->id_mobil }}">Detail</a></p>
						        	<div class="price-rate">
							        	<h3>
							        		<span class="num">Rp {{$data -> biaya_perhari}}</span>
							        		<span class="per">/per hari</span>
							        	</h3>
							        	<span class="subheading">Include Bensin 5 Liter</span>
						        </div>
						        </td>

						        <td class="price">
						        	<p class="btn-custom"><a href="#">Detail</a></p>
						        	<div class="price-rate">
							        	<h3>
							        		<span class="num">Rp - </span>
							        		<span class="per">/per bulan</span>
							        	</h3>
							        	<span class="subheading">-</span>
							        </div>
						        </td>
						      </tr><!-- END TR-->
							  @endforeach
						    </tbody>
							
							<hr>
						  </table>
						  
					  </div>
    			</div>
    		</div>
			</div>
		</section>


    
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>
@extends('layout.main')

@section('title','Data')

@section('container')
@if($errors->any())
        <div class="alert alert-danger">
          <ul>
          @foreach($errors->all() as $error)
          <li>{{ $error }}</li>
          @endforeach
          </ul>
        </div>
        @endif
    
      <section class="ftco-section services-section img" style="background-image: url(images/bg_2.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
          <br><br>
          	
            <h2 class="mb-3">DATA MOBIL</h2>
            <span class="subheading">   by <i class="icon-heart color-danger" aria-hidden="true"></i> <a href="/" target="_blank">ALPHAMIDI</a>
          </div>
        </div>
    	</div>
    </div>
    </section>
	
    <section class="ftco-section">
    	<div class="container">
    		<div class="row">
    			@foreach($datas as $data)
				<div class="col-md-3">
    				<div class="car-wrap ftco-animate">
						<div class="img d-flex align-items-end">
							<img width="100%" height="200px"  src="{{asset('images/'.$data->images)}}">
    							
						</div>
						<div class="price-wrap ">
    							<span class="rate">{{$data -> biaya_perhari}}</span>
    							<p class="from-day">
    								<span>From</span>
    								<span>/Day</span>
    							</p>
							</div>
    					<div class="text p-4 text-center">
    						<h2 class="mb-0">{{$data -> nama_mobil}}</h2>
    						<span>{{$data -> merk}}</span>
    						<p class="d-flex mb-0 d-block"><a href="{{url('/mobil/edit/'.$data->id_mobil)}}" class="btn btn-black btn-outline-black mr-1">EDIT</a> <a href="/mobil/hapus/{{ $data->id_mobil }}" class="btn btn-black btn-outline-black ml-1">Delete</a></p>
    					</div>
    				</div>
    			</div>
    			@endforeach

    		</div>
        <hr>
    		<a href="{{url('/mobil_pinjam')}}" class="btn btn-primary container">Lihat Data Peminjam</a>
							<hr>
    	</div>
    </section>
	

    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div> -->


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>
@endsection
@extends('layout.main')

@section('title',  'Edit') 

@section('container')
 
<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('../../images/bg_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
        </div>
      </div>
    </section>
<div class="container">
  <section class="main-section">
    <div class="content">
    <hr>
      <h1 style="text-align:center">Edit Data Mobil</h1>
      <hr>
      @if($errors->any())
        <div class="alert alert-danger">
          <ul>
          @foreach($errors->all() as $error)
          <li><strong>{{ $error }}</strong></li>
          @endforeach
          </ul>
        </div>
        @endif
    @foreach($data as $datas)
        <form action="/mobil/update" method="post">
        <input type="hidden" name="id" value="{{ $datas->id_mobil}}"> <br/>
          {{ csrf_field() }}
          <div class="form-group">
            <label for="nama">Nama Mobil</label>
            <input type="text" class="form-control"  name="nama_mobil" value="{{ $datas->nama_mobil }}" required="required">
          </div>
          <div class="form-group">
            <label for="nomor_mobil">Nomor Mobil</label>
            <input type="text" class="form-control"  name="nomor_mobil" value="{{ $datas->nomor_mobil }}"required="required">
          </div>
          <div class="form-group">
            <label for="merk">Merk</label>
            <input type="text" class="form-control"  name="merk" value="{{ $datas->merk }}" required="required">
          </div>
          <div class="form-group">
            <label for="warna">Warna</label>
            <input type="text" class="form-control"  name="warna" value="{{ $datas->warna }}" required="required">
          </div>
          <div class="form-group">
            <label for="tahun_pembuatan">Tahun Pembuatan</label>
            <input type="date"  class="form-control" name="tahun_pembuatan" value="{{ $datas->tahun_pembuatan }}" required="required">
          </div>
          <div class="form-group">
            <label for="biaya_perhari">Biaya Perhari</label>
            <input type="text" class="form-control" name="biaya_perhari"  value="{{ $datas->biaya_perhari }}" required="required">
          </div>
          <div class="form-group">
            <label for="images">Gambar</label>
            <input type="file"  class="form-control" name="images"  value="{{ $datas->images }}" required="required">
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <input type="text"  class="form-control" name="deskripsi" value="{{ $datas->deskripsi }}" required="required">
            
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-md btn-primary">Submit</button>
            <button type="reset" class="btn btn-md btn-danger">Cancel</button>
          </div>
        
        </form>
        @endforeach
    </div>

  </section>
  </div>
@endsection



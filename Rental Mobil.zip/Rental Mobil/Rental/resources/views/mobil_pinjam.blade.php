@extends('layout.main')

@section('title',  'Pinjam') 

@section('container')

<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/bg_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
        </div>
      </div>
    </section>
<div class="container">
  <section class="main-section">
    <div class="content">
    <hr>
      <h1 style="text-align:center">Tambah Data Peminjaman</h1>
      <hr>
      @if($errors->any())
        <div class="alert alert-danger">
          <ul>
          @foreach($errors->all() as $error)
          <li><strong>{{ $error }}</strong></li>
          @endforeach
          </ul>
        </div>
        @endif
        @foreach($data as $datas)
        <form action="/mobil/sewa" method="post">
        <input type="hidden" name="id" value="{{ $datas->id_mobil }}"> <br/>
          {{ csrf_field() }}
          <div class="form-group">
            <label for="id_mobil"></label>
            <input type="hidden" class="form-control" id="id_mobil" name="id_mobil" value="{{ $datas->id_mobil}} required="required">
          </div>
          <div class="form-group">
            <label for="nama_pelanggan">Nama Pelanggan</label>
            <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" required="required">
          </div>
          <div class="form-group">
            <label for="tgl_pinjam">Tanggal Pinjam</label>
            <input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam"  required="required">
          </div>
          <div class="form-group">
            <label for="tgl_kembali">Tanggal Kembali</label>
            <input type="date" class="form-control" id="tgl_kembali" name="tgl_kembali" required="required">
          </div>
          
          <div class="form-group">
            <button type="submit" class="btn btn-md btn-primary">Submit</button>
            <button type="reset" class="btn btn-md btn-danger">Cancel</button>
          </div>
        
        </form>
    </div>
    @endforeach
  </section>
  </div>
@endsection

@extends('layout.main')

@section('title',  'Daftar') 

@section('container')

<section class="ftco-section services-section img" style="background-image: url(images/bg_2.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
          <br><br>
            <h2 class="mb-3">TAMBAH DATA MOBIL</h2>
            <span class="subheading">   by <i class="icon-heart color-danger" aria-hidden="true"></i> <a href="/" target="_blank">ALPHAMIDI</a>
          </div>
        </div>
    	</div>
    </div>
    </section>
  <div class="container">
    <div class="content">
    <hr>
      <h1 style="text-align:center">Tambah Data Mobil</h1>
      <hr>
      @if($errors->any())
        <div class="alert alert-danger">
          <ul>
          @foreach($errors->all() as $error)
          <li><strong>{{ $error }}</strong></li>
          @endforeach
          </ul>
        </div>
        @endif

        <form action="/mobil/store" method="post">
          {{ csrf_field() }}
          <div class="form-group">
            <label for="nama">Nama Mobil</label>
            <input type="text" class="form-control" id="nama_mobil" name="nama_mobil" required="required">
          </div>
          <div class="form-group">
            <label for="nomor_mobil">Nomor Mobil</label>
            <input type="text" class="form-control" id="nomor_mobil" name="nomor_mobil" required="required">
          </div>
          <div class="form-group">
            <label for="merk">Merk</label>
            <input type="text" class="form-control" id="merk" name="merk" required="required">
          </div>
          <div class="form-group">
            <label for="warna">Warna</label>
            <input type="text" class="form-control" id="warna" name="warna" required="required">
          </div>
          <div class="form-group">
            <label for="tahun_pembuatan">Tahun Pembuatan</label>
            <input type="date"  class="form-control" name="tahun_pembuatan" id="tahun_pembuatan" required="required">
          </div>
          <div class="form-group">
            <label for="biaya_perhari">Biaya Perhari</label>
            <input type="text" class="form-control" name="biaya_perhari" id="biaya_perhari" required="required">
          </div>
          <div class="form-group">
            <label for="images">Gambar</label>
            <input type="file"  class="form-control" name="images" id="images" required="required">
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi Mobil</label>
            <input type="text"  class="form-control" name="deskripsi" id="deskripsi" required="required">
          </div>
          <div class="form-group">
            <label for="id_jenis">Kategori Bang</label>
            <input type="text"  class="form-control" name="id_jenis" id="id_jenis" required="required">
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-md btn-primary">Submit</button>
            <button type="reset" class="btn btn-md btn-danger">Cancel</button>
          </div>
        
        </form>
        <hr>
    </div>

  </section>
  </div>
@endsection
